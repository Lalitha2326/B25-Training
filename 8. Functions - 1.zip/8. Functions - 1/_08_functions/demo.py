"""
Author : GOVIND
Date   : 09-12-2024
"""
# from _8_0_functions_ import n1, n2
from _8_0_functions_ import add_two_numbers
#
# print(n1 + n2)
add_two_numbers(20, 50)