"""
Author : GOVIND
Date   : 14-11-2024
"""
"""
High level        - 
interpreted       - executes the code line by line
dynamically typed - 

in python everything is object
oop

PVM -
__pycache__
    _introduction_.pyc
    
let x = 10
age = 25

indendation

key features:
-------------
easy to learn read understand
open source
portability - platform independent
libraries - slib(200+) - tpl(install - pip install lbn - conda install lbn)
large ecosystem


disadvantages:
--------------
-> slow
-> more memory
-> mobile applications
-> GIL

Areas of Applications:
----------------------
web applications   - flipkart whatsapp flask django fastapi(**)
scripting          - Devops 
DL ML AI DS DA     -
cyber security

print()
type()
input()
int()
float()


"""
import math
#
# name = "ramesh"
# age = 25
# loc = "bangalore"
# sal = 20500.56
# # print(name)
# # # print(name[10])
# # # print(ages)
# # print(loc)
#
# # str
# # print(type(name))
# # print(type(age))
# # print(type(loc))
# # print(type(sal))
#
#
# if sal > 5000:
#     print("don't give hike")
#     print("hello")
#     print("hi")
#
# print("python")

"""
procedural  - input()

functional - def func(x)

oop       - class ClassName:

"""
# name = "ramesh"  # static
# age = 25
# salary = 2500.56

# print(name)

'conversions - int() - float()'
name = input("enter a name: ")  # dynamic
age = int(input("enter age: "))  # dynamic
salary = float(input("enter a salary: "))  # dynamic
new_salary = salary * 2

print(type(name))
print(type(age))
print(type(salary))
print('name is', name, 'age is', age, 'and salary is', salary)
print(new_salary)